// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNNFORWARDPROP_H
#define XNNFORWARDPROP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnnforwardprop_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Axilites_BaseAddress;
} XNnforwardprop_Config;
#endif

typedef struct {
    u32 Axilites_BaseAddress;
    u32 IsReady;
} XNnforwardprop;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNnforwardprop_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNnforwardprop_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNnforwardprop_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNnforwardprop_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNnforwardprop_Initialize(XNnforwardprop *InstancePtr, u16 DeviceId);
XNnforwardprop_Config* XNnforwardprop_LookupConfig(u16 DeviceId);
int XNnforwardprop_CfgInitialize(XNnforwardprop *InstancePtr, XNnforwardprop_Config *ConfigPtr);
#else
int XNnforwardprop_Initialize(XNnforwardprop *InstancePtr, const char* InstanceName);
int XNnforwardprop_Release(XNnforwardprop *InstancePtr);
#endif

void XNnforwardprop_Start(XNnforwardprop *InstancePtr);
u32 XNnforwardprop_IsDone(XNnforwardprop *InstancePtr);
u32 XNnforwardprop_IsIdle(XNnforwardprop *InstancePtr);
u32 XNnforwardprop_IsReady(XNnforwardprop *InstancePtr);
void XNnforwardprop_EnableAutoRestart(XNnforwardprop *InstancePtr);
void XNnforwardprop_DisableAutoRestart(XNnforwardprop *InstancePtr);
u32 XNnforwardprop_Get_return(XNnforwardprop *InstancePtr);

void XNnforwardprop_Set_src(XNnforwardprop *InstancePtr, u32 Data);
u32 XNnforwardprop_Get_src(XNnforwardprop *InstancePtr);

void XNnforwardprop_InterruptGlobalEnable(XNnforwardprop *InstancePtr);
void XNnforwardprop_InterruptGlobalDisable(XNnforwardprop *InstancePtr);
void XNnforwardprop_InterruptEnable(XNnforwardprop *InstancePtr, u32 Mask);
void XNnforwardprop_InterruptDisable(XNnforwardprop *InstancePtr, u32 Mask);
void XNnforwardprop_InterruptClear(XNnforwardprop *InstancePtr, u32 Mask);
u32 XNnforwardprop_InterruptGetEnabled(XNnforwardprop *InstancePtr);
u32 XNnforwardprop_InterruptGetStatus(XNnforwardprop *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
