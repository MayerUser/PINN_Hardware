// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xnnforwardprop.h"

extern XNnforwardprop_Config XNnforwardprop_ConfigTable[];

XNnforwardprop_Config *XNnforwardprop_LookupConfig(u16 DeviceId) {
	XNnforwardprop_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XNNFORWARDPROP_NUM_INSTANCES; Index++) {
		if (XNnforwardprop_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XNnforwardprop_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XNnforwardprop_Initialize(XNnforwardprop *InstancePtr, u16 DeviceId) {
	XNnforwardprop_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XNnforwardprop_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XNnforwardprop_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

